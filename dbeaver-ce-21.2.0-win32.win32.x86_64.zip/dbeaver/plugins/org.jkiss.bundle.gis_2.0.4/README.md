# eclipse-bundle-gis
Eclipse bundle with GIS libraries
